nivel_assinatura = input('Qual é o nível da assinatura?')
faturamento_anual = int(input('Qual o faturamento anual?'))

if nivel_assinatura.upper() == "BASIC":
    print('o valor bonus é ',faturamento_anual * 0.30)
if nivel_assinatura.upper() == "SILVER":
    print('o valor bonus é ',faturamento_anual * 0.20)
if nivel_assinatura.upper() == "GOLD":
    print('o valor bonus é ',faturamento_anual * 0.10)
if nivel_assinatura.upper() == "PLATINUM":
    print('o valor bonus é ',faturamento_anual * 0.05)
