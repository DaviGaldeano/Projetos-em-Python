dicionario = {}
#inserndo elemento
dicionario ['Davi Galdeano'] = 'Aspirante oficial do exérciro brasileiro'

#inserindo à partir do input
nome_colaborador = input('Por favor, informe o nome do colaborador: ')
cargo_colaborador = input('Por favor, informe o cargo do colaborador:')
dicionario[nome_colaborador] = cargo_colaborador

for nome,cargo in dicionario.items():
    print(f'O colaborador {nome} atua no cargo de {cargo}')